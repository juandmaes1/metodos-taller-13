package taller13;

import java.util.Scanner;

public class ejer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner entrada = new Scanner(System.in);
		int a, b, resultado, opcion;
		boolean op = true;
		while(op ) {
			System.out.println("Menu");
			System.out.println("1. sumar");
			System.out.println("2. dividir");
			System.out.println("3. restar");
			System.out.println("4. multiplicar");
			System.out.println("5. salir");
			opcion = entrada.nextInt() ;
			
					
					if (opcion == 5) {
						System.out.println("hasta luego");
						break;
						
					} else 
						System.out.print("ingrese un valor");
					a = entrada.nextInt();
					System.out.print("ingrese un segundo valor");
					b = entrada.nextInt();
					{
						switch (opcion) {
						case 1:
							sumar(a,b);
							break;
						case 2:
							dividir(a,b);
							break;
						case 3:
							restar(a,b);
							break;
						case 4:
							multiplicar(a,b);
							break;
							
						default:
							System.out.print("Opcion no valida");
							
							
					}
					}
		}
		
		

	}
		public static void sumar(int a, int b){
			int suma = 0;
			suma = a+b;
			System.out.print("La suma entre" + a + " y " + b + " es igual a :" + suma);
		}
		public static void dividir(int a, int b) {
			int division = 0;
			division = a/b;
			System.out.print("La division entre" + a + " y " + b + " es igual a :" + division);
		}
		public static int restar(int a, int b) {
			int resta = 0;
			resta = a - b;
			
			return resta;
		}
		public static int multiplicar(int a, int b) {
			int multiplicar = 0;
			multiplicar = a*b;
			return multiplicar;
		}
		
		

}
		
