package taller13;

import java.util.Scanner;

public class ejer4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in);
		int a, b;
		System.out.print("ingrese un valor");
		a = entrada.nextInt();
		System.out.print("ingrese un segundo valor");
		b = entrada.nextInt();
		
		mayor(a,b);
	}
	public static void mayor(int a, int b) {
		System.out.println("El mayor de los dos números es " + Math.max(a, b));
	}
}
