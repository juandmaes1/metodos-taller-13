package taller13;

import java.util.Scanner;

public class ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in);
		int a, b;
		System.out.print("ingrese un valor");
		a = entrada.nextInt();
		System.out.print("ingrese un segundo valor");
		b = entrada.nextInt();
		
		mayor(a,b);
	}
	public static String mayor(int a, int b) {
		return("El mayor de los dos números es " + Math.max(a, b));
	}
}
