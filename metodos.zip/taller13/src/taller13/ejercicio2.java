package taller13;

public class ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
