package taller13;

import java.util.Scanner;

public class ejercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner entrada = new Scanner(System.in);
		int a, b;
		System.out.print("ingrese un valor");
		a = entrada.nextInt();
		System.out.print("ingrese un segundo valor");
		b = entrada.nextInt();
		pares(a);
	}
	public static boolean pares(int a) {
		boolean espar= false;
		if (a % 2 == 0) {
			espar = true;
		} else {
			espar = false;
		}
		
		return espar;
}
}