package taller13;

import java.util.Scanner;

public class ejercicio9 {

	
		// TODO Auto-generated method stub
		public static final Scanner entrada = new Scanner(System.in);
		
		  public static void main(String[] args) {
		int opcion;
		System.out.println("\n\n---------------------------");
		System.out.println("1-Area de un rectangulo");
		System.out.println("2-Area de un circulo");
		System.out.println("3-Area de un trinagulo");
		System.out.println("4-Salir");
		System.out.println("Selecciona una opción");
		opcion = entrada.nextInt();
		
		if (opcion == 4) {
			System.out.println("hasta luego");			
			
		} else 						switch (opcion) {
		case 1:
			rectangulo();
			break;
		case 2:
			circulo();
			break;
		case 3:
			triangulo();
			break;			
		default:
			System.out.print("Opcion no valida");
			
			
	}
	




}
public static String rectangulo(){
	int a, b;
	System.out.print("ingrese la base");
	a = entrada.nextInt();
	System.out.print("ingrese la altura");
	b = entrada.nextInt();
	return("el area de su rectangulo es" + a*b);
	
	
}
public static String circulo() {
	int a;
	System.out.print("ingrese el radio");
	a = entrada.nextInt();
	return("el area de su circulo es" + 3.14*(a*a));
	
}
public static String triangulo() {
	int a, b;
	System.out.print("ingrese la base");
	a = entrada.nextInt();
	System.out.print("ingrese la altura");
	b = entrada.nextInt();
	return("el area de su triangulo es" + (a*b)/2);

}
}
