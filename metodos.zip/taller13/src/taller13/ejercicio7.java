package taller13;

import java.util.Scanner;

public class ejercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in);
		int a, b;
		System.out.print("ingrese un valor");
		a = entrada.nextInt();
		System.out.print("ingrese un segundo valor");
		b = entrada.nextInt();
		doble(a,b);
	}
	public static String doble(int a, int b) {
		return("EL DOBLE DE A ES " + 2*a + " EL DOLBE DE B ES " + 2*b);
	}
}
