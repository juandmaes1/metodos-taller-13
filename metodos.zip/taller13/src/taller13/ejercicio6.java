package taller13;

import java.util.Scanner;

public class ejercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner entrada = new Scanner(System.in);
		String a, b;
		System.out.print("ingrese un valor");
		a = entrada.next();
		System.out.print("ingrese un segundo valor");
		b = entrada.next();
		igualdad(a,b);
	}
	public static void igualdad(String a, String b) {
		System.out.println(a.equals(b));
		
	}
}
