package taller13;

import javax.swing.JOptionPane;

public class ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a;

		a = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero a"));
		
		numero(a);
	}
	public static void numero(int a) {
		String a1 = "quiero vaciones";
		for(int i=0;i<a;i++) {
			System.out.println(a1);
		}
	}

	}


